<!-- [ Pre-loader ] start -->
<div class="loader-bg">
    <div class="loader-track">
        <div class="loader-fill"></div>
    </div>
</div>
<!-- [ Pre-loader ] End -->
<?php /**PATH D:\projects\crm-demo\resources\views/layouts/parts/loader.blade.php ENDPATH**/ ?>