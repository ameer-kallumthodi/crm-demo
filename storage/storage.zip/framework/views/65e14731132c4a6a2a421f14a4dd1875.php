<?php $__env->startSection('title', 'Invoices - ' . $student->name); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Invoices for <?php echo e($student->name); ?></h4>
                        <div>
                            <a href="<?php echo e(route('admin.invoices.create', $student->id)); ?>" class="btn btn-primary">
                                <i class="fas fa-plus"></i> Create Invoice
                            </a>
                            <a href="<?php echo e(route('admin.converted-leads.index')); ?>" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Back to Students
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Student Information -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6>Student Information</h6>
                            <p><strong>Name:</strong> <?php echo e($student->name); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($student->code); ?> <?php echo e($student->phone); ?></p>
                            <p><strong>Email:</strong> <?php echo e($student->email ?? 'N/A'); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Course Information</h6>
                            <p><strong>Course:</strong> <?php echo e($student->course->title ?? 'N/A'); ?></p>
                            <p><strong>Batch:</strong> <?php echo e($student->batch->title ?? 'N/A'); ?></p>
                            <p><strong>Academic Assistant:</strong> <?php echo e($student->academicAssistant->name ?? 'N/A'); ?></p>
                        </div>
                    </div>

                    <!-- Summary Cards -->
                    <div class="row mb-4">
                        <div class="col-md-3">
                            <div class="card bg-primary text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Total Invoices</h5>
                                    <h3><?php echo e($summary['total_invoices']); ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-info text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Total Amount</h5>
                                    <h3>₹<?php echo e(number_format($summary['total_amount'], 2)); ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-success text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Total Paid</h5>
                                    <h3>₹<?php echo e(number_format($summary['total_paid'], 2)); ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card bg-warning text-white">
                                <div class="card-body">
                                    <h5 class="card-title">Total Pending</h5>
                                    <h3>₹<?php echo e(number_format($summary['total_pending'], 2)); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Invoices Table -->
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Invoice #</th>
                                    <th>Type</th>
                                    <th>Details</th>
                                    <th>Total Amount</th>
                                    <th>Paid Amount</th>
                                    <th>Pending Amount</th>
                                    <th>Status</th>
                                    <th>Invoice Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($invoice->invoice_number); ?></td>
                                    <td>
                                        <?php if($invoice->invoice_type == 'course'): ?>
                                            <span class="badge bg-primary">Course</span>
                                        <?php elseif($invoice->invoice_type == 'e-service'): ?>
                                            <span class="badge bg-info">E-Service</span>
                                        <?php elseif($invoice->invoice_type == 'batch_change'): ?>
                                            <span class="badge bg-warning">Batch Change</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($invoice->invoice_type == 'course'): ?>
                                            <?php echo e($invoice->course->title ?? 'N/A'); ?>

                                        <?php elseif($invoice->invoice_type == 'e-service'): ?>
                                            <?php echo e($invoice->service_name); ?>

                                        <?php elseif($invoice->invoice_type == 'batch_change'): ?>
                                            <?php echo e($invoice->batch->title ?? 'N/A'); ?> (<?php echo e($invoice->batch->course->title ?? 'N/A'); ?>)
                                        <?php endif; ?>
                                    </td>
                                    <td>₹<?php echo e(number_format($invoice->total_amount, 2)); ?></td>
                                    <td>₹<?php echo e(number_format($invoice->paid_amount, 2)); ?></td>
                                    <td>₹<?php echo e(number_format($invoice->pending_amount, 2)); ?></td>
                                    <td>
                                        <?php if($invoice->status == 'Not Paid'): ?>
                                            <span class="badge bg-danger">Not Paid</span>
                                        <?php elseif($invoice->status == 'Partially Paid'): ?>
                                            <span class="badge bg-warning">Partially Paid</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Fully Paid</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($invoice->invoice_date->format('M d, Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('admin.invoices.show', $invoice->id)); ?>" class="btn btn-sm btn-info" title="View Invoice">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.payments.index', $invoice->id)); ?>" class="btn btn-sm btn-primary" title="Manage Payments">
                                            <i class="fas fa-credit-card"></i>
                                        </a>
                                        <?php if($invoice->payments->where('status', 'Approved')->count() > 0): ?>
                                            <a href="<?php echo e(route('admin.payments.tax-invoice', $invoice->payments->where('status', 'Approved')->first()->id)); ?>" class="btn btn-sm btn-warning" title="Tax Invoice" target="_blank">
                                                <i class="fas fa-file-invoice"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.payments.tax-invoice-pdf', $invoice->payments->where('status', 'Approved')->first()->id)); ?>" class="btn btn-sm btn-danger" title="View PDF" target="_blank">
                                                <i class="fas fa-file-pdf"></i>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="10" class="text-center">No invoices found for this student.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mantis', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\crm-demo\resources\views/admin/invoices/index.blade.php ENDPATH**/ ?>