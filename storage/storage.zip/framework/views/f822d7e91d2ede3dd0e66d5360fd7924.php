<?php $__env->startSection('title', 'Invoice Details - ' . $invoice->invoice_number); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="mb-0">Invoice Details - <?php echo e($invoice->invoice_number); ?></h4>
                        <div>
                            <a href="<?php echo e(route('admin.payments.create', $invoice->id)); ?>" class="btn btn-success">
                                <i class="fas fa-plus"></i> Add Payment
                            </a>
                            <a href="<?php echo e(route('admin.payments.index', $invoice->id)); ?>" class="btn btn-primary">
                                <i class="fas fa-credit-card"></i> View Payments
                            </a> 
                            <a href="<?php echo e(route('admin.invoices.index', $invoice->student_id)); ?>" class="btn btn-secondary">
                                <i class="fas fa-arrow-left"></i> Back to Invoices
                            </a>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <!-- Invoice Information -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6>Invoice Information</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>Invoice Number:</strong></td>
                                    <td><?php echo e($invoice->invoice_number); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Type:</strong></td>
                                    <td>
                                        <?php if($invoice->invoice_type == 'course'): ?>
                                            <span class="badge bg-primary">Course</span>
                                        <?php elseif($invoice->invoice_type == 'e-service'): ?>
                                            <span class="badge bg-info">E-Service</span>
                                        <?php elseif($invoice->invoice_type == 'batch_change'): ?>
                                            <span class="badge bg-warning">Batch Change</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong>Invoice Date:</strong></td>
                                    <td><?php echo e($invoice->invoice_date->format('M d, Y')); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Status:</strong></td>
                                    <td>
                                        <?php if($invoice->status == 'Not Paid'): ?>
                                            <span class="badge bg-danger">Not Paid</span>
                                        <?php elseif($invoice->status == 'Partially Paid'): ?>
                                            <span class="badge bg-warning">Partially Paid</span>
                                        <?php else: ?>
                                            <span class="badge bg-success">Fully Paid</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td><strong>Total Amount:</strong></td>
                                    <td>₹<?php echo e(number_format($invoice->total_amount, 2)); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Paid Amount:</strong></td>
                                    <td>₹<?php echo e(number_format($invoice->paid_amount, 2)); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Pending Amount:</strong></td>
                                    <td>₹<?php echo e(number_format($invoice->pending_amount, 2)); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6>Student Information</h6>
                            <table class="table table-borderless">
                                <tr>
                                    <td><strong>Name:</strong></td>
                                    <td><?php echo e($invoice->student->name); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Phone:</strong></td>
                                    <td><?php echo e($invoice->student->code); ?> <?php echo e($invoice->student->phone); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Email:</strong></td>
                                    <td><?php echo e($invoice->student->email ?? 'N/A'); ?></td>
                                </tr>
                                <?php if($invoice->invoice_type == 'course'): ?>
                                <tr>
                                    <td><strong>Course:</strong></td>
                                    <td><?php echo e($invoice->course->title); ?></td>
                                </tr>
                                <?php elseif($invoice->invoice_type == 'e-service'): ?>
                                <tr>
                                    <td><strong>Service:</strong></td>
                                    <td><?php echo e($invoice->service_name); ?></td>
                                </tr>
                                <?php elseif($invoice->invoice_type == 'batch_change'): ?>
                                <tr>
                                    <td><strong>New Batch:</strong></td>
                                    <td><?php echo e($invoice->batch->title ?? 'N/A'); ?> (<?php echo e($invoice->batch->course->title ?? 'N/A'); ?>)</td>
                                </tr>
                                <?php endif; ?>
                                <tr>
                                    <td><strong>Batch:</strong></td>
                                    <td><?php echo e($invoice->student->batch->title ?? 'N/A'); ?></td>
                                </tr>
                                <tr>
                                    <td><strong>Academic Assistant:</strong></td>
                                    <td><?php echo e($invoice->student->academicAssistant->name ?? 'N/A'); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- Payments History -->
                    <div class="row">
                        <div class="col-12">
                            <h6>Payments History</h6>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Payment Date</th>
                                            <th>Amount</th>
                                            <th>Payment Type</th>
                                            <th>Transaction ID</th>
                                            <th>Status</th>
                                            <th>Created By</th>
                                            <th>File</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $invoice->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($index + 1); ?></td>
                                            <td><?php echo e($payment->created_at->format('M d, Y h:i A')); ?></td>
                                            <td>₹<?php echo e(number_format($payment->amount_paid, 2)); ?></td>
                                            <td><?php echo e($payment->payment_type); ?></td>
                                            <td><?php echo e($payment->transaction_id ?? 'N/A'); ?></td>
                                            <td>
                                                <?php if($payment->status == 'Pending Approval'): ?>
                                                    <span class="badge bg-warning">Pending Approval</span>
                                                <?php elseif($payment->status == 'Approved'): ?>
                                                    <span class="badge bg-success">Approved</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Rejected</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($payment->createdBy->name); ?></td>
                                            <td>
                                                <?php if($payment->file_upload): ?>
                                                    <div class="btn-group btn-group-sm" role="group" aria-label="Receipt/Proof">
                                                        <a href="<?php echo e(route('admin.payments.download', $payment->id)); ?>" class="btn btn-outline-primary" title="Download Receipt/Proof">
                                                            <i class="fas fa-download"></i>
                                                        </a>
                                                        <a href="<?php echo e(route('admin.payments.view', $payment->id)); ?>" class="btn btn-primary" title="View Receipt/Proof" target="_blank">
                                                            <i class="fas fa-file-alt"></i>
                                                        </a>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="text-muted">No file</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="d-flex flex-wrap gap-1 justify-content-start">
                                                    <a href="<?php echo e(route('admin.payments.show', $payment->id)); ?>" class="btn btn-sm btn-info" title="View Payment">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <?php if($payment->status == 'Approved'): ?>
                                                        <?php if($invoice->invoice_type === 'course' && $firstPayment && $payment->id == $firstPayment->id): ?>
                                                            <!-- Tax Invoice only for course invoices, first approved payment -->
                                                            <a href="<?php echo e(route('admin.payments.tax-invoice', $payment->id)); ?>" class="btn btn-sm btn-warning" title="Tax Invoice" target="_blank">
                                                                <i class="fas fa-file-invoice"></i>
                                                            </a>
                                                            <a href="<?php echo e(route('admin.payments.tax-invoice-pdf', $payment->id)); ?>" class="btn btn-sm btn-danger" title="View PDF" target="_blank">
                                                                <i class="fas fa-file-pdf"></i>
                                                            </a>
                                                        <?php else: ?>
                                                            <!-- Receipt for all payments, and for non-course types -->
                                                            <a href="<?php echo e(route('admin.payments.payment-receipt', $payment->id)); ?>" class="btn btn-sm btn-warning" title="Payment Receipt" target="_blank">
                                                                <i class="fas fa-receipt"></i>
                                                            </a>
                                                            <a href="<?php echo e(route('admin.payments.payment-receipt-pdf', $payment->id)); ?>" class="btn btn-sm btn-danger" title="View PDF" target="_blank">
                                                                <i class="fas fa-file-pdf"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <?php if($payment->status == 'Pending Approval'): ?>
                                                        <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_finance()): ?>
                                                        <button type="button" class="btn btn-sm btn-success approve-payment-btn" 
                                                                data-payment-id="<?php echo e($payment->id); ?>"
                                                                data-amount="<?php echo e($payment->amount_paid); ?>"
                                                                data-previous-balance="<?php echo e($invoice->total_amount - $payment->previous_balance); ?>"
                                                                data-payment-type="<?php echo e($payment->payment_type); ?>"
                                                                data-transaction-id="<?php echo e($payment->transaction_id); ?>"
                                                                data-file-upload="<?php echo e($payment->file_upload); ?>"
                                                                title="Approve Payment">
                                                            <i class="fas fa-check"></i>
                                                        </button>
                                                        <button type="button" class="btn btn-sm btn-danger reject-payment-btn" 
                                                                data-payment-id="<?php echo e($payment->id); ?>"
                                                                data-amount="<?php echo e($payment->amount_paid); ?>"
                                                                data-payment-type="<?php echo e($payment->payment_type); ?>"
                                                                title="Reject Payment">
                                                            <i class="fas fa-times"></i>
                                                        </button>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="9" class="text-center">No payments found for this invoice.</td>
                                        </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Payment Approval Modal -->
<div class="modal fade" id="approvePaymentModal" tabindex="-1" aria-labelledby="approvePaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="approvePaymentModalLabel">Approve Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Please review the payment details before approving:</strong>
                </div>
                <div class="row">
                    <div class="col-6">
                        <strong>Amount:</strong>
                    </div>
                    <div class="col-6" id="approveAmount">
                        <!-- Amount will be populated here -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <strong>Previous Balance:</strong>
                    </div>
                    <div class="col-6" id="approvePreviousBalance">
                        <!-- Previous balance will be populated here -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <strong>Payment Type:</strong>
                    </div>
                    <div class="col-6" id="approvePaymentType">
                        <!-- Payment type will be populated here -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <strong>Transaction ID:</strong>
                    </div>
                    <div class="col-6" id="approveTransactionId">
                        <!-- Transaction ID will be populated here -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <strong>Receipt/Proof:</strong>
                    </div>
                    <div class="col-6" id="approveFile">
                        <!-- File will be populated here -->
                    </div>
                </div>
                <hr>
                <p class="text-muted">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Once approved, this payment will be added to the invoice total and cannot be undone.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="approvePaymentForm" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-check me-2"></i>Approve Payment
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Payment Rejection Modal -->
<div class="modal fade" id="rejectPaymentModal" tabindex="-1" aria-labelledby="rejectPaymentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="rejectPaymentModalLabel">Reject Payment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    <strong>Are you sure you want to reject this payment?</strong>
                </div>
                <div class="row">
                    <div class="col-6">
                        <strong>Amount:</strong>
                    </div>
                    <div class="col-6" id="rejectAmount">
                        <!-- Amount will be populated here -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-6">
                        <strong>Payment Type:</strong>
                    </div>
                    <div class="col-6" id="rejectPaymentType">
                        <!-- Payment type will be populated here -->
                    </div>
                </div>
                <hr>
                <p class="text-muted">
                    <i class="fas fa-info-circle me-2"></i>
                    Rejected payments will not be added to the invoice total.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <form id="rejectPaymentForm" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-times me-2"></i>Reject Payment
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Handle approve payment button clicks
        document.querySelectorAll('.approve-payment-btn').forEach(function(button) {
            button.addEventListener('click', function() {
                const paymentId = this.getAttribute('data-payment-id');
                const amount = this.getAttribute('data-amount');
                const previousBalance = this.getAttribute('data-previous-balance');
                const paymentType = this.getAttribute('data-payment-type');
                const transactionId = this.getAttribute('data-transaction-id');
                const fileUpload = this.getAttribute('data-file-upload');

                showApproveModal(paymentId, amount, previousBalance, paymentType, transactionId, fileUpload);
            });
        });

        // Handle reject payment button clicks
        document.querySelectorAll('.reject-payment-btn').forEach(function(button) {
            button.addEventListener('click', function() {
                const paymentId = this.getAttribute('data-payment-id');
                const amount = this.getAttribute('data-amount');
                const paymentType = this.getAttribute('data-payment-type');

                showRejectModal(paymentId, amount, paymentType);
            });
        });
    });

    // Show approve payment modal
    function showApproveModal(paymentId, amount, previousBalance, paymentType, transactionId, fileUpload) {
        document.getElementById('approveAmount').textContent = '₹' + parseFloat(amount).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
        document.getElementById('approvePreviousBalance').textContent = '₹' + parseFloat(previousBalance).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
        document.getElementById('approvePaymentType').textContent = paymentType;
        document.getElementById('approveTransactionId').textContent = transactionId || 'N/A';

        // Handle file display
        const fileElement = document.getElementById('approveFile');
        if (fileUpload && fileUpload !== '') {
            const fileName = fileUpload.split('/').pop(); // Get filename from path
            const fileUrl = '<?php echo e(route("admin.payments.view", ":id")); ?>'.replace(':id', paymentId);
            fileElement.innerHTML = `<a href="${fileUrl}" target="_blank" class="btn btn-sm btn-outline-primary">
            <i class="fas fa-eye me-1"></i>View ${fileName}
        </a>`;
        } else {
            fileElement.innerHTML = '<span class="text-muted">No file uploaded</span>';
        }

        document.getElementById('approvePaymentForm').action = '<?php echo e(route("admin.payments.approve", ":id")); ?>'.replace(':id', paymentId);

        const modal = new bootstrap.Modal(document.getElementById('approvePaymentModal'), {
            backdrop: 'static',
            keyboard: false
        });
        modal.show();
    }

    // Show reject payment modal
    function showRejectModal(paymentId, amount, paymentType) {
        document.getElementById('rejectAmount').textContent = '₹' + parseFloat(amount).toLocaleString('en-IN', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
        document.getElementById('rejectPaymentType').textContent = paymentType;
        document.getElementById('rejectPaymentForm').action = '<?php echo e(route("admin.payments.reject", ":id")); ?>'.replace(':id', paymentId);

        const modal = new bootstrap.Modal(document.getElementById('rejectPaymentModal'), {
            backdrop: 'static',
            keyboard: false
        });
        modal.show();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mantis', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\crm-demo\resources\views/admin/invoices/show.blade.php ENDPATH**/ ?>