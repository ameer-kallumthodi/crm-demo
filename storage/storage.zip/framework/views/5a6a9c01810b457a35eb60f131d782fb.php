<form action="<?php echo e(route('admin.batches.submit')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="row g-3">
        <div class="col-lg-6">
            <div class="p-1">
                <label for="stream_id" class="form-label">Stream <span class="text-danger">*</span></label>
                <select class="form-control" name="stream_id" id="stream_id" required>
                    <option value="">Select Stream</option>
                    <?php $__currentLoopData = $streams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stream): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($stream->id); ?>"><?php echo e($stream->title); ?> (<?php echo e($stream->course->title); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="p-1">
                <label for="title" class="form-label">Title <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="title" id="title" required>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="p-1">
                <label for="is_active" class="form-label">Status</label>
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" name="is_active" id="is_active" checked>
                    <label class="form-check-label" for="is_active">Active</label>
                </div>
            </div>
        </div>


        <div class="col-12 p-2">
            <button class="btn btn-primary float-end" type="submit">Save Batch</button>
        </div>
    </div>
</form>
<?php /**PATH D:\projects\crm-demo\resources\views/admin/batches/add.blade.php ENDPATH**/ ?>