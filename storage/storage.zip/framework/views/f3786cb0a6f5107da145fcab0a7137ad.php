<div class="container p-2">
    <form id="leadStatusEditForm" action="<?php echo e(route('admin.lead-statuses.update', $edit_data->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row">
            <div class="col-md-12">
                <div class="mb-3">
                    <label class="form-label" for="title">Title <span class="text-danger">*</span></label>
                    <input type="text" name="title" class="form-control" id="title" value="<?php echo e($edit_data->title); ?>" placeholder="Enter Lead Status Title" required>
                </div>
            </div>

            <div class="col-md-12">
                <div class="mb-3">
                    <label class="form-label" for="description">Description</label>
                    <textarea name="description" class="form-control" id="description" rows="3" placeholder="Enter Description"><?php echo e($edit_data->description); ?></textarea>
                </div>
            </div>

            <div class="col-md-12">
                <div class="mb-3">
                    <label class="form-label" for="interest_status">Interest Status <span class="text-danger">*</span></label>
                    <select name="interest_status" class="form-select" id="interest_status" required>
                        <option value="">Select Interest Status</option>
                        <option value="1" <?php echo e($edit_data->interest_status == 1 ? 'selected' : ''); ?>>Hot</option>
                        <option value="2" <?php echo e($edit_data->interest_status == 2 ? 'selected' : ''); ?>>Warm</option>
                        <option value="3" <?php echo e($edit_data->interest_status == 3 ? 'selected' : ''); ?>>Cold</option>
                    </select>
                </div>
            </div>

            <div class="col-md-12">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1" <?php echo e($edit_data->is_active ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="is_active">
                        Active
                    </label>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-end gap-2">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-success">Update</button>
        </div>
    </form>
</div>

<script>
$(document).ready(function() {
    $('#leadStatusEditForm').on('submit', function(e) {
        e.preventDefault();
        
        const form = $(this);
        const formData = new FormData(this);
        const submitBtn = form.find('button[type="submit"]');
        const originalText = submitBtn.html();
        
        // Show loading state
        submitBtn.prop('disabled', true);
        submitBtn.html('<i class="ti ti-loader-2 spin"></i> Updating...');
        
        $.ajax({
            url: form.attr('action'),
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                'X-HTTP-Method-Override': 'PUT'
            },
            success: function(response) {
                // Close modal
                $('#small_modal').modal('hide');
                
                // Show success message
                toast_success('Lead Status updated successfully!');
                
                // Redirect to the index page
                setTimeout(() => {
                    window.location.href = '<?php echo e(route("admin.lead-statuses.index")); ?>';
                }, 1000);
            },
            error: function(xhr) {
                let errorMessage = 'An error occurred while updating the lead status.';
                
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMessage = xhr.responseJSON.message;
                } else if (xhr.responseJSON && xhr.responseJSON.errors) {
                    const errors = xhr.responseJSON.errors;
                    errorMessage = Object.values(errors).flat().join('<br>');
                }
                
                toast_danger(errorMessage);
                
                // Re-enable submit button
                submitBtn.prop('disabled', false);
                submitBtn.html(originalText);
            }
        });
    });
});
</script>
<?php /**PATH D:\projects\crm-demo\resources\views/admin/lead-statuses/edit.blade.php ENDPATH**/ ?>