<?php $__env->startSection('title', 'Leads'); ?>

<?php $__env->startSection('content'); ?>
<!-- [ breadcrumb ] start -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="page-header-title">
                    <h5 class="m-b-10">Leads Management</h5>
                </div>
            </div>
            <div class="col-md-6">
                <ul class="breadcrumb d-flex justify-content-end">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item">Leads</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- [ breadcrumb ] end -->

<?php if(request('search_key')): ?>
<!-- [ Search Results Indicator ] start -->
<div class="alert alert-info alert-dismissible fade show" role="alert">
    <div class="d-flex align-items-center">
        <i class="ti ti-search me-2"></i>
        <div class="flex-grow-1">
            <strong>Search Results:</strong> Showing leads matching "<?php echo e(request('search_key')); ?>"
        </div>
        <a href="<?php echo e(route('leads.index')); ?>" class="btn btn-sm btn-outline-info">
            <i class="ti ti-x"></i> Clear Search
        </a>
    </div>
</div>
<!-- [ Search Results Indicator ] end -->
<?php endif; ?>

<!-- [ Filter Section ] start -->
<div class="row mb-3">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('leads.index')); ?>" id="dateFilterForm">
                    <div class="row g-3 align-items-end">
                        <!-- From Date -->
                        <div class="col-6 col-md-4 col-lg-2">
                            <label for="date_from" class="form-label">From Date</label>
                            <input type="date" class="form-control form-control-sm" name="date_from" id="date_from"
                                value="<?php echo e(request('date_from', \Carbon\Carbon::now()->subDays(7)->format('Y-m-d'))); ?>">
                        </div>

                        <!-- To Date -->
                        <div class="col-6 col-md-4 col-lg-2">
                            <label for="date_to" class="form-label">To Date</label>
                            <input type="date" class="form-control form-control-sm" name="date_to" id="date_to"
                                value="<?php echo e(request('date_to', \Carbon\Carbon::now()->format('Y-m-d'))); ?>">
                        </div>

                        <!-- Status -->
                        <div class="col-6 col-md-4 col-lg-2">
                            <label for="filter_lead_status_id" class="form-label">Status</label>
                            <select class="form-select form-select-sm" name="lead_status_id" id="filter_lead_status_id">
                                <option value="">All Statuses</option>
                                <?php $__currentLoopData = $leadStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($status->id); ?>" <?php echo e(request('lead_status_id') == $status->id ? 'selected' : ''); ?>>
                                    <?php echo e($status->title); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Source -->
                        <div class="col-6 col-md-4 col-lg-2">
                            <label for="filter_lead_source_id" class="form-label">Source</label>
                            <select class="form-select form-select-sm" name="lead_source_id" id="filter_lead_source_id">
                                <option value="">All Sources</option>
                                <?php $__currentLoopData = $leadSources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($source->id); ?>" <?php echo e(request('lead_source_id') == $source->id ? 'selected' : ''); ?>>
                                    <?php echo e($source->title); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Course -->
                        <div class="col-6 col-md-4 col-lg-2">
                            <label for="course_id" class="form-label">Course</label>
                            <select class="form-select form-select-sm" name="course_id" id="course_id">
                                <option value="">All Courses</option>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($course->id); ?>" <?php echo e(request('course_id') == $course->id ? 'selected' : ''); ?>>
                                    <?php echo e($course->title); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <!-- Rating -->
                        <div class="col-6 col-md-4 col-lg-2">
                            <label for="rating" class="form-label">Rating</label>
                            <select class="form-select form-select-sm" name="rating" id="rating">
                                <option value="">All Ratings</option>
                                <?php for($i = 1; $i <= 10; $i++): ?>
                                    <option value="<?php echo e($i); ?>" <?php echo e(request('rating') == $i ? 'selected' : ''); ?>>
                                    <?php echo e($i); ?>/10
                                    </option>
                                    <?php endfor; ?>
                            </select>
                        </div>

                        <!-- Telecaller (conditional) -->
                        <?php if(!$isTelecaller || $isTeamLead): ?>
                        <div class="col-6 col-md-4 col-lg-2">
                            <label for="telecaller_id" class="form-label">Telecaller</label>
                            <select class="form-select form-select-sm" name="telecaller_id" id="telecaller_id">
                                <option value="">All Telecallers</option>
                                <?php $__currentLoopData = $telecallers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telecaller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($telecaller->id); ?>" <?php echo e(request('telecaller_id') == $telecaller->id ? 'selected' : ''); ?>>
                                    <?php echo e($telecaller->name); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <?php endif; ?>

                        <!-- Action Buttons -->
                        <div class="col-12 col-lg-2">
                            <div class="d-flex gap-2 flex-wrap">
                                <button type="submit" class="btn btn-primary btn-sm flex-fill flex-lg-grow-0">
                                    <i class="ti ti-filter me-1"></i> Filter
                                </button>
                                <a href="<?php echo e(route('leads.index')); ?>" class="btn btn-outline-secondary btn-sm flex-fill flex-lg-grow-0">
                                    <i class="ti ti-x me-1"></i> Clear
                                </a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- [ Filter Section ] end -->

<!-- [ Main Content ] start -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <!-- Desktop Header -->
                <div class="d-none d-md-flex justify-content-between align-items-center">
                    <h5 class="mb-0">All Leads</h5>
                    <div class="d-flex gap-2">
                        <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_team_lead()): ?>
                        <a href="javascript:void(0);" class="btn btn-primary btn-sm px-3"
                            onclick="show_ajax_modal('<?php echo e(route('leads.add')); ?>', 'Add New Lead')">
                            <i class="ti ti-plus"></i> Add Lead
                        </a>
                        <a href="javascript:void(0);" class="btn btn-outline-primary btn-sm px-3"
                            onclick="show_ajax_modal('<?php echo e(route('leads.bulk-upload.test')); ?>', 'Bulk Upload Leads')">
                            <i class="ti ti-upload"></i> Bulk Upload
                        </a>
                        <a href="javascript:void(0);" class="btn btn-outline-success btn-sm px-3"
                            onclick="show_large_modal('<?php echo e(route('admin.leads.bulk-reassign')); ?>', 'Bulk Reassign Leads')">
                            <i class="ti ti-users"></i> Bulk Reassign
                        </a>
                        <a href="javascript:void(0);" class="btn btn-outline-danger btn-sm px-3"
                            onclick="show_ajax_modal('<?php echo e(route('admin.leads.bulk-delete')); ?>', 'Bulk Delete Leads')">
                            <i class="ti ti-trash"></i> Bulk Delete
                        </a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Mobile Header -->
                <div class="d-md-none">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0">All Leads</h5>
                        <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_team_lead()): ?>
                        <a href="javascript:void(0);" class="btn btn-primary btn-sm"
                            onclick="show_ajax_modal('<?php echo e(route('leads.add')); ?>', 'Add New Lead')">
                            <i class="ti ti-plus"></i> Add
                        </a>
                        <?php endif; ?>
                    </div>

                    <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_team_lead()): ?>
                    <div class="row g-2">
                        <div class="col-6">
                            <a href="javascript:void(0);" class="btn btn-outline-primary btn-sm w-100"
                                onclick="show_ajax_modal('<?php echo e(route('leads.bulk-upload.test')); ?>', 'Bulk Upload Leads')">
                                <i class="ti ti-upload me-1"></i> Upload
                            </a>
                        </div>
                        <div class="col-6">
                            <a href="javascript:void(0);" class="btn btn-outline-success btn-sm w-100"
                                onclick="show_large_modal('<?php echo e(route('admin.leads.bulk-reassign')); ?>', 'Bulk Reassign Leads')">
                                <i class="ti ti-users me-1"></i> Reassign
                            </a>
                        </div>
                        <div class="col-6">
                            <a href="javascript:void(0);" class="btn btn-outline-danger btn-sm w-100"
                                onclick="show_ajax_modal('<?php echo e(route('admin.leads.bulk-delete')); ?>', 'Bulk Delete Leads')">
                                <i class="ti ti-trash me-1"></i> Delete
                            </a>
                        </div>
                        <div class="col-6">
                            <!-- Empty space for better layout -->
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">

                <!-- Desktop Table View -->
                <div class="d-none d-lg-block">
                    <div class="table-responsive" style="overflow-x: auto;">
                        <table class="table table-hover data_table_basic" id="leadsTable" style="min-width: 1700px;">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Actions</th>
                                    <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_telecaller() || \App\Helpers\RoleHelper::is_academic_assistant() || \App\Helpers\RoleHelper::is_admission_counsellor()): ?>
                                    <th>Registration Details</th>
                                    <?php endif; ?>
                                    <th>Name</th>
                                    <th>Profile</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>Interest</th>
                                    <th>Rating</th>
                                    <th>Source</th>
                                    <th>Course</th>
                                    <th>Telecaller</th>
                                    <th>Place</th>
                                    <th>Followup Date</th>
                                    <th>Last Reason</th>
                                    <th>Remarks</th>
                                    <th>Date</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="javascript:void(0);" class="btn btn-sm btn-outline-primary"
                                                onclick="show_large_modal('<?php echo e(route('leads.ajax-show', $lead->id)); ?>', 'View Lead')"
                                                title="View Lead">
                                                <i class="ti ti-eye"></i>
                                            </a>
                                            <?php if(\App\Helpers\PermissionHelper::has_lead_action_permission()): ?>
                                            <a href="javascript:void(0);" class="btn btn-sm btn-outline-secondary"
                                                onclick="show_ajax_modal('<?php echo e(route('leads.ajax-edit', $lead->id)); ?>', 'Edit Lead')"
                                                title="Edit Lead">
                                                <i class="ti ti-edit"></i>
                                            </a>
                                            <a href="javascript:void(0);" class="btn btn-sm btn-outline-success"
                                                onclick="show_ajax_modal('<?php echo e(route('leads.status-update', $lead->id)); ?>', 'Update Status')"
                                                title="Update Status">
                                                <i class="ti ti-arrow-up"></i>
                                            </a>
                                            <?php if(!$lead->is_converted && $lead->studentDetails && (strtolower($lead->studentDetails->status ?? '') === 'approved')): ?>
                                            <a href="javascript:void(0);" class="btn btn-sm btn-outline-warning"
                                                onclick="show_ajax_modal('<?php echo e(route('leads.convert', $lead->id)); ?>', 'Convert Lead')"
                                                title="Convert Lead">
                                                <i class="ti ti-refresh"></i>
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                        <br>
                                        <hr><br>
                                        <div class="btn-group" role="group">
                                            <?php if($lead->lead_status_id == 6): ?>
                                            <a href="https://docs.google.com/forms/d/e/1FAIpQLSchtc8xlKUJehZNmzoKTkRvwLwk4-SGjzKSHM2UFToAhgdTlQ/viewform?usp=sf_link"
                                                target="_blank"
                                                class="btn btn-sm btn-outline-info"
                                                title="Demo Conduction Form">
                                                <i class="ti ti-file-text"></i>
                                            </a>
                                            <?php endif; ?>
                                            <?php if($lead->phone && is_telecaller()): ?>
                                            <?php
                                            $currentUserId = session('user_id') ?? (\App\Helpers\AuthHelper::getCurrentUserId() ?? 0);
                                            ?>
                                            <?php if($currentUserId > 0): ?>
                                            <button class="btn btn-sm btn-outline-success voxbay-call-btn"
                                                data-lead-id="<?php echo e($lead->id); ?>"
                                                data-telecaller-id="<?php echo e($currentUserId); ?>"
                                                title="Call Lead">
                                                <i class="ti ti-phone"></i>
                                            </button>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('leads.call-logs', $lead)); ?>"
                                                class="btn btn-sm btn-outline-info"
                                                title="View Call Logs">
                                                <i class="ti ti-phone-call"></i>
                                            </a>
                                            <?php if(!$isTelecaller || $isTeamLead): ?>
                                            <a href="javascript:void(0);" class="btn btn-sm btn-outline-danger"
                                                onclick="delete_modal('<?php echo e(route('leads.destroy', $lead->id)); ?>')"
                                                title="Delete Lead">
                                                <i class="ti ti-trash"></i>
                                            </a>
                                            <?php endif; ?>
                                        </div>

                                        <?php endif; ?>
                                    </td>
                                    <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_telecaller() || \App\Helpers\RoleHelper::is_academic_assistant() || \App\Helpers\RoleHelper::is_admission_counsellor()): ?>
                                    <td class="text-center">
                                        <?php if($lead->studentDetails): ?>
                                        <div class="d-flex flex-column gap-1">
                                            <span class="badge bg-success">Form Submitted</span>
                                            <small class="text-muted"><?php echo e($lead->studentDetails->course->title ?? 'Unknown Course'); ?></small>
                                            <?php if($lead->studentDetails->status): ?>
                                            <span class="badge 
                                                        <?php if($lead->studentDetails->status == 'approved'): ?> bg-success
                                                        <?php elseif($lead->studentDetails->status == 'rejected'): ?> bg-danger
                                                        <?php else: ?> bg-warning
                                                        <?php endif; ?>">
                                                <?php echo e(ucfirst($lead->studentDetails->status)); ?>

                                            </span>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('leads.registration-details', $lead->id)); ?>"
                                                class="btn btn-sm btn-outline-primary mt-1"
                                                title="View Registration Details">
                                                <i class="ti ti-eye me-1"></i>View Details
                                            </a>
                                        </div>
                                        <?php else: ?>
                                        <?php if($lead->course_id == 1): ?>
                                        <a href="<?php echo e(route('public.lead.nios.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open NIOS Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 2): ?>
                                        <a href="<?php echo e(route('public.lead.bosse.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open BOSSE Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 3): ?>
                                        <a href="<?php echo e(route('public.lead.medical-coding.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open Medical Coding Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 4): ?>
                                        <a href="<?php echo e(route('public.lead.hospital-admin.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open Hospital Administration Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 5): ?>
                                        <a href="<?php echo e(route('public.lead.eschool.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open E-School Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 6): ?>
                                        <a href="<?php echo e(route('public.lead.eduthanzeel.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open Eduthanzeel Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 7): ?>
                                        <a href="<?php echo e(route('public.lead.ttc.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open TTC Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 8): ?>
                                        <a href="<?php echo e(route('public.lead.hotel-mgmt.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open Hotel Management Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 9): ?>
                                        <a href="<?php echo e(route('public.lead.ugpg.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open UG/PG Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 10): ?>
                                        <a href="<?php echo e(route('public.lead.python.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open Python Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 11): ?>
                                        <a href="<?php echo e(route('public.lead.digital-marketing.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open Digital Marketing Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 12): ?>
                                        <a href="<?php echo e(route('public.lead.ai-automation.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open AI Automation Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 13): ?>
                                        <a href="<?php echo e(route('public.lead.web-dev.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open Web Development & Designing Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 14): ?>
                                        <a href="<?php echo e(route('public.lead.vibe-coding.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open Vibe Coding Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php elseif($lead->course_id == 15): ?>
                                        <a href="<?php echo e(route('public.lead.graphic-designing.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-outline-warning" title="Open Graphic Designing Registration Form">
                                            <i class="ti ti-external-link"></i>
                                        </a>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                    <?php endif; ?>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avtar avtar-s rounded-circle bg-light-primary me-2 d-flex align-items-center justify-content-center">
                                                <span class="f-16 fw-bold text-primary"><?php echo e(strtoupper(substr($lead->title, 0, 1))); ?></span>
                                            </div>
                                            <div>
                                                <h6 class="mb-0"><?php echo e($lead->title); ?></h6>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <?php if($lead->isProfileIncomplete()): ?>
                                            <div class="me-2">
                                                <div class="progress" style="width: 60px; height: 8px;">
                                                    <div class="progress-bar 
                                                            <?php if($lead->profile_status == 'incomplete'): ?> bg-danger
                                                            <?php elseif($lead->profile_status == 'partial'): ?> bg-warning
                                                            <?php elseif($lead->profile_status == 'almost_complete'): ?> bg-info
                                                            <?php else: ?> bg-success
                                                            <?php endif; ?>"
                                                        role="progressbar"
                                                        style="width: <?php echo e($lead->profile_completeness); ?>%"
                                                        aria-valuenow="<?php echo e($lead->profile_completeness); ?>"
                                                        aria-valuemin="0"
                                                        aria-valuemax="100">
                                                    </div>
                                                </div>
                                            </div>
                                            <span class="badge 
                                                    <?php if($lead->profile_status == 'incomplete'): ?> bg-danger
                                                    <?php elseif($lead->profile_status == 'partial'): ?> bg-warning
                                                    <?php elseif($lead->profile_status == 'almost_complete'): ?> bg-info
                                                    <?php else: ?> bg-success
                                                    <?php endif; ?>"
                                                data-bs-toggle="tooltip"
                                                data-bs-placement="top"
                                                title="Missing: <?php echo e(implode(', ', array_slice($lead->getMissingFields(), 0, 5))); ?><?php echo e(count($lead->getMissingFields()) > 5 ? '...' : ''); ?>">
                                                <?php echo e($lead->profile_completeness); ?>%
                                            </span>
                                            <?php else: ?>
                                            <span class="badge bg-success">
                                                <i class="ti ti-check"></i> Complete
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td><?php echo e(\App\Helpers\PhoneNumberHelper::display($lead->code, $lead->phone)); ?></td>
                                    <td><?php echo e($lead->email ?? '-'); ?></td>
                                    <td>
                                        <span class="badge <?php echo e(\App\Helpers\StatusHelper::getLeadStatusColorClass($lead->leadStatus->id)); ?>">
                                            <?php echo e($lead->leadStatus->title); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php if($lead->interest_status): ?>
                                        <span class="badge bg-<?php echo e($lead->interest_status_color); ?>">
                                            <?php echo e($lead->interest_status_label); ?>

                                        </span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary">Not Set</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($lead->rating): ?>
                                        <span class="badge bg-primary"><?php echo e($lead->rating); ?>/10</span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary">Not Rated</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($lead->leadSource->title ?? '-'); ?></td>
                                    <td><?php echo e($lead->course->title ?? '-'); ?></td>
                                    <td><?php echo e($lead->telecaller->name ?? 'Unassigned'); ?></td>
                                    <td><?php echo e($lead->place ?? '-'); ?></td>
                                    <td>
                                        <?php if($lead->followup_date): ?>
                                        <span class="badge bg-warning"><?php echo e($lead->followup_date->format('M d, Y')); ?></span>
                                        <?php else: ?>
                                        -
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                        $lastActivityWithReason = $lead->leadActivities->first();
                                        ?>
                                        <?php if($lastActivityWithReason): ?>
                                        <?php echo e(Str::limit($lastActivityWithReason->reason, 20)); ?>

                                        <?php else: ?>
                                        -
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($lead->remarks ? Str::limit($lead->remarks, 30) : '-'); ?></td>
                                    <td><?php echo e($lead->created_at->format('M d, Y')); ?></td>
                                    <td><?php echo e($lead->created_at->format('H:i A')); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="19" class="text-center py-4">
                                        <div class="text-muted">
                                            <i class="ti ti-inbox f-48 mb-3 d-block"></i>
                                            No leads found
                                        </div>
                                    </td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <br>
                <hr>
                <br>

                <!-- Mobile Card View -->
                <div class="d-lg-none">
                    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card mb-2">
                        <div class="card-body p-3">
                            <!-- Lead Header -->
                            <div class="d-flex align-items-start justify-content-between mb-2">
                                <div class="d-flex align-items-center flex-grow-1">
                                    <div class="avtar avtar-s rounded-circle bg-light-primary me-2 d-flex align-items-center justify-content-center">
                                        <span class="f-14 fw-bold text-primary"><?php echo e(strtoupper(substr($lead->title, 0, 1))); ?></span>
                                    </div>
                                    <div class="flex-grow-1">
                                        <h6 class="mb-0 fw-bold f-14"><?php echo e($lead->title); ?></h6>
                                        <small class="text-muted f-11">#<?php echo e($index + 1); ?></small>
                                    </div>
                                </div>
                                <!-- Action buttons in header -->
                                <div class="d-flex gap-1">
                                    <a href="javascript:void(0);" class="btn btn-sm btn-outline-primary"
                                        onclick="show_large_modal('<?php echo e(route('leads.ajax-show', $lead->id)); ?>', 'View Lead')"
                                        title="View Lead">
                                        <i class="ti ti-eye f-12"></i>
                                    </a>
                                    <a href="javascript:void(0);" class="btn btn-sm btn-outline-secondary"
                                        onclick="show_ajax_modal('<?php echo e(route('leads.ajax-edit', $lead->id)); ?>', 'Edit Lead')"
                                        title="Edit Lead">
                                        <i class="ti ti-edit f-12"></i>
                                    </a>
                                    <?php if(!$isTelecaller || $isTeamLead): ?>
                                    <a href="javascript:void(0);" class="btn btn-sm btn-outline-danger"
                                        onclick="delete_modal('<?php echo e(route('leads.destroy', $lead->id)); ?>')"
                                        title="Delete Lead">
                                        <i class="ti ti-trash f-12"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Profile Completeness Indicator -->
                            <div class="mb-2">
                                <?php if($lead->isProfileIncomplete()): ?>
                                <div class="d-flex align-items-center">
                                    <small class="text-muted me-2 f-11">Profile:</small>
                                    <div class="progress me-2" style="width: 80px; height: 6px;">
                                        <div class="progress-bar 
                                                <?php if($lead->profile_status == 'incomplete'): ?> bg-danger
                                                <?php elseif($lead->profile_status == 'partial'): ?> bg-warning
                                                <?php elseif($lead->profile_status == 'almost_complete'): ?> bg-info
                                                <?php else: ?> bg-success
                                                <?php endif; ?>"
                                            role="progressbar"
                                            style="width: <?php echo e($lead->profile_completeness); ?>%"
                                            aria-valuenow="<?php echo e($lead->profile_completeness); ?>"
                                            aria-valuemin="0"
                                            aria-valuemax="100">
                                        </div>
                                    </div>
                                    <span class="badge 
                                            <?php if($lead->profile_status == 'incomplete'): ?> bg-danger
                                            <?php elseif($lead->profile_status == 'partial'): ?> bg-warning
                                            <?php elseif($lead->profile_status == 'almost_complete'): ?> bg-info
                                            <?php else: ?> bg-success
                                            <?php endif; ?> f-10"
                                        data-bs-toggle="tooltip"
                                        data-bs-placement="top"
                                        title="Missing: <?php echo e(implode(', ', array_slice($lead->getMissingFields(), 0, 5))); ?><?php echo e(count($lead->getMissingFields()) > 5 ? '...' : ''); ?>">
                                        <?php echo e($lead->profile_completeness); ?>%
                                    </span>
                                </div>
                                <?php if(count($lead->getMissingFields()) > 0): ?>
                                <div class="mt-1">
                                    <small class="text-muted f-10">
                                        Missing: <?php echo e(implode(', ', array_slice($lead->getMissingFields(), 0, 5))); ?><?php echo e(count($lead->getMissingFields()) > 5 ? '...' : ''); ?>

                                    </small>
                                </div>
                                <?php endif; ?>
                                <?php else: ?>
                                <div class="d-flex align-items-center">
                                    <small class="text-muted me-2 f-11">Profile:</small>
                                    <span class="badge bg-success f-10">
                                        <i class="ti ti-check me-1"></i> Complete
                                    </span>
                                </div>
                                <?php endif; ?>
                            </div>

                            <!-- Lead Details - Compact Layout -->
                            <div class="row g-1 mb-2">
                                <div class="col-6">
                                    <div class="d-flex align-items-center">
                                        <i class="ti ti-phone f-12 text-muted me-1"></i>
                                        <small class="text-muted f-11"><?php echo e(\App\Helpers\PhoneNumberHelper::display($lead->code, $lead->phone)); ?></small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="d-flex align-items-center">
                                        <i class="ti ti-mail f-12 text-muted me-1"></i>
                                        <small class="text-muted f-11"><?php echo e($lead->email ?? '-'); ?></small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="d-flex align-items-center">
                                        <i class="ti ti-circle f-12 text-muted me-1"></i>
                                        <span class="badge <?php echo e(\App\Helpers\StatusHelper::getLeadStatusColorClass($lead->leadStatus->id)); ?> f-11">
                                            <?php echo e($lead->leadStatus->title); ?>

                                        </span>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="d-flex align-items-center">
                                        <i class="ti ti-flame f-12 text-muted me-1"></i>
                                        <?php if($lead->interest_status): ?>
                                        <span class="badge bg-<?php echo e($lead->interest_status_color); ?> f-10">
                                            <?php echo e($lead->interest_status_label); ?>

                                        </span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary f-10">Not Set</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="d-flex align-items-center">
                                        <i class="ti ti-star f-12 text-muted me-1"></i>
                                        <?php if($lead->rating): ?>
                                        <span class="badge bg-primary f-10"><?php echo e($lead->rating); ?>/10</span>
                                        <?php else: ?>
                                        <span class="badge bg-secondary f-10">Not Rated</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="d-flex align-items-center">
                                        <i class="ti ti-user f-12 text-muted me-1"></i>
                                        <small class="text-muted f-11"><?php echo e($lead->telecaller->name ?? 'Unassigned'); ?></small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="d-flex align-items-center">
                                        <i class="ti ti-book f-12 text-muted me-1"></i>
                                        <small class="text-muted f-11"><?php echo e($lead->course->title ?? '-'); ?></small>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="d-flex align-items-center">
                                        <i class="ti ti-calendar f-12 text-muted me-1"></i>
                                        <small class="text-muted f-11"><?php echo e($lead->created_at->format('M d')); ?></small>
                                    </div>
                                </div>
                                <?php if($lead->followup_date): ?>
                                <div class="col-6">
                                    <div class="d-flex align-items-center">
                                        <i class="ti ti-clock f-12 text-muted me-1"></i>
                                        <span class="badge bg-warning f-10"><?php echo e($lead->followup_date->format('M d')); ?></span>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php
                                $lastActivityWithReason = $lead->leadActivities->first();
                                ?>
                                <?php if($lastActivityWithReason): ?>
                                <div class="col-6">
                                    <div class="d-flex align-items-center">
                                        <i class="ti ti-message f-12 text-muted me-1"></i>
                                        <span class="badge bg-info f-10" title="<?php echo e($lastActivityWithReason->reason); ?>"><?php echo e(Str::limit($lastActivityWithReason->reason, 15)); ?></span>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php if($lead->remarks): ?>
                                <div class="col-12">
                                    <div class="d-flex align-items-start">
                                        <i class="ti ti-note f-12 text-muted me-1 mt-1"></i>
                                        <small class="text-muted f-11" title="<?php echo e($lead->remarks); ?>"><?php echo e(Str::limit($lead->remarks, 50)); ?></small>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <!-- Registration Details Section -->
                                <?php if($lead->studentDetails): ?>
                                <div class="col-12 mt-2">
                                    <div class="border-top pt-2">
                                        <div class="d-flex align-items-center justify-content-between mb-2">
                                            <small class="text-muted f-11 fw-bold">Registration Details:</small>
                                            <span class="badge bg-success f-10">Form Submitted</span>
                                        </div>
                                        <div class="row g-1">
                                            <div class="col-6">
                                                <small class="text-muted f-10">Course:</small>
                                                <div class="fw-medium f-11"><?php echo e($lead->studentDetails->course->title ?? 'Unknown'); ?></div>
                                            </div>
                                            <div class="col-6">
                                                <small class="text-muted f-10">Status:</small>
                                                <div>
                                                    <span class="badge 
                                                        <?php if($lead->studentDetails->status == 'approved'): ?> bg-success
                                                        <?php elseif($lead->studentDetails->status == 'rejected'): ?> bg-danger
                                                        <?php else: ?> bg-warning
                                                        <?php endif; ?> f-10">
                                                        <?php echo e(ucfirst($lead->studentDetails->status ?? 'Pending')); ?>

                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="mt-2">
                                            <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_telecaller() || \App\Helpers\RoleHelper::is_academic_assistant() || \App\Helpers\RoleHelper::is_admission_counsellor()): ?>
                                            <a href="<?php echo e(route('leads.registration-details', $lead->id)); ?>"
                                                class="btn btn-sm btn-outline-primary"
                                                title="View Registration Details">
                                                <i class="ti ti-eye me-1"></i>View Details
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>

                            <!-- Action Buttons - Enhanced -->
                            <div class="d-flex gap-1 flex-wrap justify-content-between">
                                <!-- Left side - Status and Convert buttons -->
                                <div class="d-flex gap-1">
                                    <a href="javascript:void(0);" class="btn btn-sm btn-outline-warning"
                                        onclick="show_ajax_modal('<?php echo e(route('leads.status-update', $lead->id)); ?>', 'Update Status')"
                                        title="Update Status">
                                        <i class="ti ti-arrow-up f-12"></i>
                                    </a>
                                    <?php if(!$lead->is_converted && $lead->studentDetails && (strtolower($lead->studentDetails->status ?? '') === 'approved')): ?>
                                    <a href="javascript:void(0);" class="btn btn-sm btn-outline-success"
                                        onclick="show_ajax_modal('<?php echo e(route('leads.convert', $lead->id)); ?>', 'Convert Lead')"
                                        title="Convert Lead">
                                        <i class="ti ti-refresh f-12"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if($lead->lead_status_id == 6): ?>
                                    <a href="https://docs.google.com/forms/d/e/1FAIpQLSchtc8xlKUJehZNmzoKTkRvwLwk4-SGjzKSHM2UFToAhgdTlQ/viewform?usp=sf_link"
                                        target="_blank"
                                        class="btn btn-sm btn-outline-info"
                                        title="Demo Conduction Form">
                                        <i class="ti ti-file-text f-12"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>

                                <!-- Right side - Call and Logs buttons -->
                                <div class="d-flex gap-1">
                                    <?php if($lead->phone && is_telecaller()): ?>
                                    <?php
                                    $currentUserId = session('user_id') ?? (\App\Helpers\AuthHelper::getCurrentUserId() ?? 0);
                                    ?>
                                    <?php if($currentUserId > 0): ?>
                                    <button class="btn btn-sm btn-success voxbay-call-btn"
                                        data-lead-id="<?php echo e($lead->id); ?>"
                                        data-telecaller-id="<?php echo e($currentUserId); ?>"
                                        title="Call Lead">
                                        <i class="ti ti-phone f-12"></i>
                                    </button>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('leads.call-logs', $lead)); ?>"
                                        class="btn btn-sm btn-info"
                                        title="View Call Logs">
                                        <i class="ti ti-phone-call f-12"></i>
                                    </a>
                                    <br>
                                    <hr><br>
                                    <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_telecaller() || \App\Helpers\RoleHelper::is_academic_assistant() || \App\Helpers\RoleHelper::is_admission_counsellor()): ?>
                                    <?php if($lead->course_id == 1): ?>
                                    <a href="<?php echo e(route('public.lead.nios.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open NIOS Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 2): ?>
                                    <a href="<?php echo e(route('public.lead.bosse.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open BOSSE Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 3): ?>
                                    <a href="<?php echo e(route('public.lead.medical-coding.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open Medical Coding Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 4): ?>
                                    <a href="<?php echo e(route('public.lead.hospital-admin.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open Hospital Administration Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 5): ?>
                                    <a href="<?php echo e(route('public.lead.eschool.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open E-School Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 6): ?>
                                    <a href="<?php echo e(route('public.lead.eduthanzeel.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open Eduthanzeel Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 7): ?>
                                    <a href="<?php echo e(route('public.lead.ttc.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open TTC Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 8): ?>
                                    <a href="<?php echo e(route('public.lead.hotel-mgmt.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open Hotel Management Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 9): ?>
                                    <a href="<?php echo e(route('public.lead.ugpg.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open UG/PG Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 10): ?>
                                    <a href="<?php echo e(route('public.lead.python.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open Python Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 11): ?>
                                    <a href="<?php echo e(route('public.lead.digital-marketing.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open Digital Marketing Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 12): ?>
                                    <a href="<?php echo e(route('public.lead.ai-automation.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open AI Automation Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 13): ?>
                                    <a href="<?php echo e(route('public.lead.web-dev.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open Web Development & Designing Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 14): ?>
                                    <a href="<?php echo e(route('public.lead.vibe-coding.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open Vibe Coding Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php elseif($lead->course_id == 15): ?>
                                    <a href="<?php echo e(route('public.lead.graphic-designing.register', $lead->id)); ?>" target="_blank" class="btn btn-sm btn-warning" title="Open Graphic Designing Registration Form">
                                        <i class="ti ti-external-link f-12"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center py-4">
                        <div class="text-muted">
                            <i class="ti ti-inbox f-48 mb-3 d-block"></i>
                            <h5>No leads found</h5>
                            <p>Try adjusting your filters or add a new lead.</p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- [ Main Content ] end -->


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<style>
    /* Fix DataTables responsive dropdown icon issue */
    .dtr-control {
        position: relative;
        cursor: pointer;
    }

    .dtr-control:before {
        content: '+';
        display: inline-block;
        width: 20px;
        height: 20px;
        line-height: 18px;
        text-align: center;
        border: 1px solid #ddd;
        border-radius: 3px;
        background-color: #f8f9fa;
        color: #666;
        font-weight: bold;
        margin-right: 8px;
    }

    .dtr-control.dtr-expanded:before {
        content: '-';
        background-color: #007bff;
        color: white;
        border-color: #007bff;
    }

    /* Remove the problematic sorting_1 class styling */
    .dtr-control.sorting_1:before {
        content: '+';
    }

    /* Improve table responsiveness */
    .table-responsive {
        border: none;
    }

    #leadsTable {
        margin-bottom: 0;
    }

    #leadsTable thead th {
        border-top: none;
        font-weight: 600;
        background-color: #f8f9fa;
        white-space: nowrap;
    }

    #leadsTable tbody td {
        vertical-align: middle;
        white-space: nowrap;
    }

    /* Fix action buttons in responsive mode */
    .dtr-details {
        background-color: #f8f9fa;
        padding: 10px;
        border-left: 3px solid #007bff;
    }

    .dtr-details li {
        margin-bottom: 5px;
    }

    /* Improve mobile card layout */
    @media (max-width: 991.98px) {
        .card-body {
            padding: 0.75rem;
        }

        .mobile-card {
            margin-bottom: 0.5rem;
        }
    }

    /* Additional responsive improvements */
    @media (max-width: 1200px) {
        .table-responsive {
            font-size: 0.875rem;
        }

        #leadsTable th,
        #leadsTable td {
            padding: 0.5rem 0.25rem;
        }
    }

    /* Enhanced action button styling */
    .btn-sm {
        min-width: 32px;
        height: 32px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
    }

    .btn-sm i {
        font-size: 12px;
    }

    /* Mobile action buttons layout */
    @media (max-width: 991.98px) {
        .d-flex.gap-1 {
            gap: 0.25rem !important;
        }

        .btn-sm {
            min-width: 28px;
            height: 28px;
            padding: 0.25rem;
        }
    }

    @media (max-width: 768px) {
        .table-responsive {
            font-size: 0.8rem;
        }

        #leadsTable th,
        #leadsTable td {
            padding: 0.375rem 0.125rem;
        }

        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
        }
    }

    /* Fix DataTables info and pagination on mobile */
    .dataTables_info,
    .dataTables_paginate {
        font-size: 0.875rem;
    }

    @media (max-width: 576px) {

        .dataTables_info,
        .dataTables_paginate {
            font-size: 0.75rem;
        }

        .dataTables_length,
        .dataTables_filter {
            margin-bottom: 0.5rem;
        }
    }
</style>
<script>
    $(document).ready(function() {

        // Function to fix DataTables responsive dropdown icons
        function fixResponsiveIcons() {
            // Remove problematic classes and ensure proper icon display
            $('.dtr-control').each(function() {
                $(this).removeClass('sorting_1 sorting_2 sorting_3');
                if (!$(this).hasClass('dtr-control')) {
                    $(this).addClass('dtr-control');
                }
            });

            // Ensure proper icon styling
            $('.dtr-control:not(.dtr-expanded)').each(function() {
                if (!$(this).find('::before').length) {
                    $(this).css('position', 'relative');
                }
            });
        }

        // DataTable is now initialized globally via initializeTables() function

        // Handle global search form submission
        $('.header-search form, .drp-search form').on('submit', function(e) {
            e.preventDefault();
            const searchValue = $(this).find('input[name="search_key"]').val().trim();
            if (searchValue) {
                window.location.href = '<?php echo e(route("leads.index")); ?>?search_key=' + encodeURIComponent(searchValue);
            } else {
                window.location.href = '<?php echo e(route("leads.index")); ?>';
            }
        });

        // Handle search input enter key
        $('.header-search input, .drp-search input').on('keypress', function(e) {
            if (e.which === 13) { // Enter key
                $(this).closest('form').submit();
            }
        });

        // Action buttons are now directly accessible without dropdown
        // All functionality is handled by onclick attributes on the buttons
    });

    // Function to show registration details in a modal
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.mantis', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\crm-demo\resources\views/admin/leads/index.blade.php ENDPATH**/ ?>