<?php $__env->startSection('title', 'Converted Leads'); ?>

<?php $__env->startSection('content'); ?>
<!-- [ breadcrumb ] start -->
<div class="page-header">
    <div class="page-block">
        <div class="row align-items-center">
            <div class="col-md-6">
                <div class="page-header-title">
                    <h5 class="m-b-10">Converted Leads Management</h5>
                </div>
            </div>
            <div class="col-md-6">
                <ul class="breadcrumb d-flex justify-content-end">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item">Converted Leads</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- [ breadcrumb ] end -->

<!-- [ Filter Section ] start -->
<div class="row mb-3">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('admin.converted-leads.index')); ?>" id="filterForm">
                    <div class="row g-3 align-items-end">
                        <div class="col-12 col-sm-6 col-md-2">
                            <label for="search" class="form-label">Search</label>
                            <input type="text" class="form-control" id="search" name="search"
                                value="<?php echo e(request('search')); ?>" placeholder="Name, Phone, Email">
                        </div>
                        <div class="col-12 col-sm-6 col-md-2">
                            <label for="course_id" class="form-label">Course</label>
                            <select class="form-select" id="course_id" name="course_id">
                                <option value="">All Courses</option>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($course->id); ?>" <?php echo e(request('course_id') == $course->id ? 'selected' : ''); ?>>
                                    <?php echo e($course->title); ?>

                                </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-12 col-sm-6 col-md-2">
                            <label for="date_from" class="form-label">From Date</label>
                            <input type="date" class="form-control" id="date_from" name="date_from"
                                value="<?php echo e(request('date_from')); ?>">
                        </div>
                        <div class="col-12 col-sm-6 col-md-2">
                            <label for="date_to" class="form-label">To Date</label>
                            <input type="date" class="form-control" id="date_to" name="date_to"
                                value="<?php echo e(request('date_to')); ?>">
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="d-flex gap-2 flex-wrap">
                                <button type="submit" class="btn btn-primary">
                                    <i class="ti ti-search"></i> <span class="d-none d-sm-inline">Filter</span>
                                </button>
                                <a href="<?php echo e(route('admin.converted-leads.index')); ?>" class="btn btn-secondary">
                                    <i class="ti ti-x"></i> <span class="d-none d-sm-inline">Clear</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- [ Filter Section ] end -->

<!-- [ Main Content ] start -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Converted Leads List</h5>
            </div>
            <div class="card-body">
                <!-- Desktop Table View -->
                <div class="d-none d-lg-block">
                    <div class="table-responsive">
                        <table class="table table-hover data_table_basic" id="convertedLeadsTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Register Number</th>
                                    <th>Course</th>
                                    <th>Academic Assistant</th>
                                    <th>Converted Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $convertedLeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $convertedLead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="avtar avtar-s rounded-circle bg-light-success me-2 d-flex align-items-center justify-content-center">
                                                <span class="f-16 fw-bold text-success"><?php echo e(strtoupper(substr($convertedLead->name, 0, 1))); ?></span>
                                            </div>
                                            <div>
                                                <h6 class="mb-0"><?php echo e($convertedLead->name); ?></h6>
                                                <small class="text-muted">ID: <?php echo e($convertedLead->lead_id); ?></small>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e(\App\Helpers\PhoneNumberHelper::display($convertedLead->code, $convertedLead->phone)); ?></td>
                                    <td><?php echo e($convertedLead->email ?? 'N/A'); ?></td>
                                    <td>
                                        <?php if($convertedLead->register_number): ?>
                                        <span class="badge bg-success"><?php echo e($convertedLead->register_number); ?></span>
                                        <?php else: ?>
                                        <span class="text-muted">Not Set</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($convertedLead->course ? $convertedLead->course->title : 'N/A'); ?></td>
                                    <td><?php echo e($convertedLead->academicAssistant ? $convertedLead->academicAssistant->name : 'N/A'); ?></td>
                                    <td><?php echo e($convertedLead->created_at->format('M d, Y')); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('admin.converted-leads.show', $convertedLead->id)); ?>" class="btn btn-sm btn-outline-primary" title="View Details">
                                                <i class="ti ti-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.invoices.index', $convertedLead->id)); ?>" class="btn btn-sm btn-success" title="View Invoice">
                                                <i class="ti ti-receipt"></i>
                                            </a>
                                            <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_academic_assistant() || \App\Helpers\RoleHelper::is_admission_counsellor()): ?>
                                            <button type="button" class="btn btn-sm btn-info update-register-btn" title="Update Register Number"
                                                data-url="<?php echo e(route('admin.converted-leads.update-register-number-modal', $convertedLead->id)); ?>"
                                                data-title="Update Register Number">
                                                <i class="ti ti-edit"></i>
                                            </button>
                                            <?php if($convertedLead->register_number): ?>
                                                <?php
                                                    $idCard = \App\Models\ConvertedLeadIdCard::where('converted_lead_id', $convertedLead->id)->first();
                                                ?>
                                                <?php if($idCard): ?>
                                                    <a href="<?php echo e(route('admin.converted-leads.id-card-view', $convertedLead->id)); ?>" class="btn btn-sm btn-warning" title="View ID Card" target="_blank">
                                                        <i class="ti ti-id"></i>
                                                    </a>
                                                <?php else: ?>
                                                    <form action="<?php echo e(route('admin.converted-leads.id-card-generate', $convertedLead->id)); ?>" method="post" style="display:inline-block" class="id-card-generate-form">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-sm btn-warning" title="Generate ID Card" data-loading-text="Generating...">
                                                            <i class="ti ti-id"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="9" class="text-center">No converted leads found</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Mobile Card View -->
                <div class="d-lg-none">
                    <?php $__empty_1 = true; $__currentLoopData = $convertedLeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $convertedLead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card mb-3">
                        <div class="card-body">
                            <!-- Lead Header -->
                            <div class="d-flex align-items-center mb-3">
                                <div class="avtar avtar-s rounded-circle bg-light-success me-3 d-flex align-items-center justify-content-center">
                                    <span class="f-16 fw-bold text-success"><?php echo e(strtoupper(substr($convertedLead->name, 0, 1))); ?></span>
                                </div>
                                <div class="flex-grow-1">
                                    <h6 class="mb-1 fw-bold"><?php echo e($convertedLead->name); ?></h6>
                                    <small class="text-muted">ID: <?php echo e($convertedLead->lead_id); ?></small>
                                </div>
                                <div class="dropdown">
                                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                        <i class="ti ti-dots-vertical"></i>
                                    </button>
                                    <ul class="dropdown-menu dropdown-menu-end">
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('admin.converted-leads.show', $convertedLead->id)); ?>">
                                                <i class="ti ti-eye me-2"></i>View Details
                                            </a>
                                        </li>
                                        <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_academic_assistant() || \App\Helpers\RoleHelper::is_admission_counsellor() || \App\Helpers\RoleHelper::is_finance() || \App\Helpers\RoleHelper::is_post_sales()): ?>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('admin.invoices.index', $convertedLead->id)); ?>">
                                                <i class="ti ti-receipt me-2"></i>View Invoice
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_academic_assistant() || \App\Helpers\RoleHelper::is_admission_counsellor()): ?>
                                        <li>
                                            <a class="dropdown-item update-register-btn" href="#"
                                                data-url="<?php echo e(route('admin.converted-leads.update-register-number-modal', $convertedLead->id)); ?>"
                                                data-title="Update Register Number">
                                                <i class="ti ti-edit me-2"></i>Update Register Number
                                            </a>
                                        </li>
                                        <?php if($convertedLead->register_number): ?>
                                        <li>
                                            <a class="dropdown-item" href="<?php echo e(route('admin.converted-leads.id-card-pdf', $convertedLead->id)); ?>" target="_blank">
                                                <i class="ti ti-id me-2"></i>Generate ID Card PDF
                                            </a>
                                        </li>
                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>

                            <!-- Lead Details -->
                            <div class="row g-2 mb-3">
                                <div class="col-6">
                                    <small class="text-muted d-block">Phone</small>
                                    <span class="fw-medium"><?php echo e(\App\Helpers\PhoneNumberHelper::display($convertedLead->code, $convertedLead->phone)); ?></span>
                                </div>
                                <div class="col-6">
                                    <small class="text-muted d-block">Email</small>
                                    <span class="fw-medium"><?php echo e($convertedLead->email ?? 'N/A'); ?></span>
                                </div>
                                <div class="col-6">
                                    <small class="text-muted d-block">Course</small>
                                    <span class="fw-medium"><?php echo e($convertedLead->course ? $convertedLead->course->title : 'N/A'); ?></span>
                                </div>
                                <div class="col-6">
                                    <small class="text-muted d-block">Academic Assistant</small>
                                    <span class="fw-medium"><?php echo e($convertedLead->academicAssistant ? $convertedLead->academicAssistant->name : 'N/A'); ?></span>
                                </div>
                                <div class="col-6">
                                    <small class="text-muted d-block">Register Number</small>
                                    <?php if($convertedLead->register_number): ?>
                                    <span class="badge bg-success"><?php echo e($convertedLead->register_number); ?></span>
                                    <?php else: ?>
                                    <span class="text-muted">Not Set</span>
                                    <?php endif; ?>
                                </div>
                                <div class="col-6">
                                    <small class="text-muted d-block">Converted Date</small>
                                    <span class="fw-medium"><?php echo e($convertedLead->created_at->format('M d, Y')); ?></span>
                                </div>
                            </div>

                            <!-- Action Buttons -->
                            <div class="d-flex gap-2 flex-wrap">
                                <a href="<?php echo e(route('admin.converted-leads.show', $convertedLead->id)); ?>"
                                    class="btn btn-sm btn-primary">
                                    <i class="ti ti-eye me-1"></i>View Details
                                </a>
                                <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_academic_assistant() || \App\Helpers\RoleHelper::is_admission_counsellor() || \App\Helpers\RoleHelper::is_finance() || \App\Helpers\RoleHelper::is_post_sales()): ?>
                                <a href="<?php echo e(route('admin.invoices.index', $convertedLead->id)); ?>"
                                    class="btn btn-sm btn-success">
                                    <i class="ti ti-receipt me-1"></i>View Invoice
                                </a>
                                <?php endif; ?>
                                <?php if(\App\Helpers\RoleHelper::is_admin_or_super_admin() || \App\Helpers\RoleHelper::is_academic_assistant() || \App\Helpers\RoleHelper::is_admission_counsellor()): ?>
                                <button type="button" class="btn btn-sm btn-info update-register-btn"
                                    data-url="<?php echo e(route('admin.converted-leads.update-register-number-modal', $convertedLead->id)); ?>"
                                    data-title="Update Register Number">
                                    <i class="ti ti-edit me-1"></i>Update Register
                                </button>
                                <?php if($convertedLead->register_number): ?>
                                <a href="<?php echo e(route('admin.converted-leads.id-card-pdf', $convertedLead->id)); ?>"
                                    class="btn btn-sm btn-warning" target="_blank">
                                    <i class="ti ti-id me-1"></i>ID Card PDF
                                </a>
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="text-center py-5">
                        <div class="text-muted">
                            <i class="ti ti-check-circle f-48 mb-3 d-block"></i>
                            <h5>No converted leads found</h5>
                            <p>Try adjusting your filters or check back later.</p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- [ Main Content ] end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.spin {
    animation: spin 1s linear infinite;
}
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        // Handle filter form submission
        $('#filterForm').on('submit', function(e) {
            e.preventDefault();

            // Get form data
            const formData = new FormData(this);
            const params = new URLSearchParams();

            // Add form data to params
            for (let [key, value] of formData.entries()) {
                if (value.trim() !== '') {
                    params.append(key, value);
                }
            }

            // Redirect with filter parameters
            const url = new URL(window.location.href);
            url.search = params.toString();
            window.location.href = url.toString();
        });

        // Handle clear button
        $('a[href="<?php echo e(route("admin.converted-leads.index")); ?>"]').on('click', function(e) {
            e.preventDefault();
            window.location.href = '<?php echo e(route("admin.converted-leads.index")); ?>';
        });

        // Handle update register number button clicks
        $('.update-register-btn').on('click', function(e) {
            e.preventDefault();
            const url = $(this).data('url');
            const title = $(this).data('title');
            show_small_modal(url, title);
        });

        // Handle ID card generation form submission
        $(document).off('submit', '.id-card-generate-form').on('submit', '.id-card-generate-form', function(e) {
            e.preventDefault();
            e.stopImmediatePropagation();
            
            const form = $(this);
            const button = form.find('button[type="submit"]');
            
            // Prevent multiple submissions
            if (button.prop('disabled')) {
                return false;
            }
            
            const originalText = button.html();
            const loadingText = button.data('loading-text');
            
            // Show loading state
            button.prop('disabled', true).html('<i class="ti ti-loader-2 spin"></i> ' + loadingText);
            
            // Submit form via AJAX
            $.ajax({
                url: form.attr('action'),
                type: 'POST',
                data: form.serialize(),
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                success: function(response) {
                    if (response.success) {
                        toast_success(response.message);
                        // Reload page to show updated button
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    }
                },
                error: function(xhr) {
                    console.error('Error generating ID card:', xhr);
                    toast_error('Error generating ID card. Please try again.');
                    // Reset button
                    button.prop('disabled', false).html(originalText);
                }
            });
            
            return false;
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.mantis', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\projects\crm-demo\resources\views/admin/converted-leads/index.blade.php ENDPATH**/ ?>