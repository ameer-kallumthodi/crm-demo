<!-- [ Sidebar Menu ] start -->
<nav class="pc-sidebar">
    <div class="navbar-wrapper">
        <div class="m-header">
            <a href="<?php echo e(route('dashboard')); ?>" class="b-brand text-primary">
                <!-- ========   Change your logo from here   ============ -->
                <img src="<?php echo e(asset('storage/logo.png')); ?>" class="img-fluid logo-lg" alt="logo" 
                     style="height: 200px !important; width: 100px !important; object-fit: contain;padding: 5px !important;"
                     onerror="this.src='<?php echo e(asset('assets/mantis/images/logo-dark.svg')); ?>'">
            </a>
        </div>
        <div class="navbar-content">
            <ul class="pc-navbar">
                <li class="pc-item pc-caption">
                    <label>Navigation</label>
                </li>
                <?php if(has_permission('dashboard/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-dashboard"></i>
                        </span>
                        <span class="pc-mtext">Dashboard</span>
                    </a>
                </li>
                <?php endif; ?>
                
                <?php if(has_permission('leads/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('leads.index') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('leads.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-users"></i>
                        </span>
                        <span class="pc-mtext">Leads</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if(has_permission('leads/followup')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('leads.followup') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('leads.followup')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-clock"></i>
                        </span>
                        <span class="pc-mtext">Follow-up Leads</span>
                    </a>
                </li>
                <?php endif; ?>

                
                <?php if(has_permission('admin/converted-leads/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.converted-leads.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.converted-leads.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-user-check"></i>
                        </span>
                        <span class="pc-mtext">Converted Leads</span>
                    </a>
                </li>
                <?php endif; ?>
                
                
                <?php if(has_permission('admin/telecallers/index') || has_permission('admin/admins/index') || has_permission('admin/admission-counsellors/index') || has_permission('admin/academic-assistants/index')): ?>
                <li class="pc-item pc-caption">
                    <label>User Management</label>
                </li>
                <?php if(has_permission('admin/telecallers/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.telecallers.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.telecallers.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-phone"></i>
                        </span>
                        <span class="pc-mtext">Telecallers</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('admin/admission-counsellors/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.admission-counsellors.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.admission-counsellors.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-user-plus"></i>
                        </span>
                        <span class="pc-mtext">Admission Counsellors</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('admin/academic-assistants/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.academic-assistants.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.academic-assistants.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-user-check"></i>
                        </span>
                        <span class="pc-mtext">Academic Assistants</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('admin/finance/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.finance.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.finance.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-currency-dollar"></i>
                        </span>
                        <span class="pc-mtext">Finance</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('admin/post-sales/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.post-sales.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.post-sales.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-headset"></i>
                        </span>
                        <span class="pc-mtext">Post-sales</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('admin/admins/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.admins.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.admins.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-shield"></i>
                        </span>
                        <span class="pc-mtext">Admin Users</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>
                
                
                
                <?php if(has_permission('admin/lead-statuses/index') || has_permission('admin/lead-sources/index')): ?>
                <li class="pc-item pc-caption">
                    <label>Lead Management</label>
                </li>
                <?php if(has_permission('admin/lead-statuses/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.lead-statuses.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.lead-statuses.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-flag"></i>
                        </span>
                        <span class="pc-mtext">Lead Status</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('admin/lead-sources/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.lead-sources.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.lead-sources.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-tag"></i>
                        </span>
                        <span class="pc-mtext">Lead Source</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>

                
                
                <?php if(has_permission('admin/reports/leads')): ?>
                <li class="pc-item pc-caption">
                    <label>Reports</label>
                </li>
                <li class="pc-item <?php echo e(request()->routeIs('admin.reports.leads') || request()->routeIs('admin.reports.lead-status') || request()->routeIs('admin.reports.lead-source') || request()->routeIs('admin.reports.team') || request()->routeIs('admin.reports.telecaller') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.reports.leads')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-chart-pie"></i>
                        </span>
                        <span class="pc-mtext">Lead Reports</span>
                    </a>
                </li>
                <?php endif; ?>
                
                
                <?php if(is_super_admin()): ?>
                <li class="pc-item pc-caption">
                    <label>Advanced Reports</label>
                </li>
                <li class="pc-item <?php echo e(request()->routeIs('admin.reports.lead-efficiency*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.reports.lead-efficiency')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-chart-line"></i>
                        </span>
                        <span class="pc-mtext">Source Efficiency</span>
                    </a>
                </li>
                <li class="pc-item <?php echo e(request()->routeIs('admin.reports.lead-stage-movement*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.reports.lead-stage-movement')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-arrow-right"></i>
                        </span>
                        <span class="pc-mtext">Stage Movement</span>
                    </a>
                </li>
                <li class="pc-item <?php echo e(request()->routeIs('admin.reports.lead-aging*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.reports.lead-aging')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-clock"></i>
                        </span>
                        <span class="pc-mtext">Lead Aging</span>
                    </a>
                </li>
                <li class="pc-item <?php echo e(request()->routeIs('admin.reports.team-wise*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.reports.team-wise')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-users"></i>
                        </span>
                        <span class="pc-mtext">Team-Wise Report</span>
                    </a>
                </li>
                <?php if(has_permission('admin/reports/course-summary')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.reports.course-summary*') || request()->routeIs('admin.reports.course-leads*') || request()->routeIs('admin.reports.course-converted-leads*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.reports.course-summary')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-book"></i>
                        </span>
                        <span class="pc-mtext">Course Reports</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>
                
                
                <?php if(has_permission('admin/notifications/index')): ?>
                <li class="pc-item pc-caption">
                    <label>Notifications</label>
                </li>
                <li class="pc-item <?php echo e(request()->routeIs('admin.notifications.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.notifications.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-bell"></i>
                        </span>
                        <span class="pc-mtext">Manage Notifications</span>
                    </a>
                </li>
                <?php endif; ?>
                
                
                <?php if(has_permission('admin/call-logs/index')): ?>
                <li class="pc-item pc-caption">
                    <label>Call Management</label>
                </li>
                <li class="pc-item <?php echo e(request()->routeIs('admin.call-logs.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.call-logs.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-phone"></i>
                        </span>
                        <span class="pc-mtext">Call Logs</span>
                    </a>
                </li>
                <?php endif; ?>
                
                
                <?php if(is_super_admin()): ?>
                <li class="pc-item pc-caption">
                    <label>Telecaller Tracking</label>
                </li>
                <li class="pc-item <?php echo e(request()->routeIs('admin.telecaller-tracking.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.telecaller-tracking.dashboard')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-chart-line"></i>
                        </span>
                        <span class="pc-mtext">Tracking Dashboard</span>
                    </a>
                </li>
                <li class="pc-item <?php echo e(request()->routeIs('admin.telecaller-tasks.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.telecaller-tasks.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-notes"></i>
                        </span>
                        <span class="pc-mtext">Task Management</span>
                    </a>
                </li>
                <?php endif; ?>
                
                
                <?php if(has_permission('admin/courses/index') || has_permission('admin/countries/index') || has_permission('admin/teams/index') || has_permission('admin/subjects/index') || has_permission('admin/course-documents/index')): ?>
                <li class="pc-item pc-caption">
                    <label>Master Data</label>
                </li>
                <?php if(has_permission('admin/courses/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.courses.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.courses.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-book"></i>
                        </span>
                        <span class="pc-mtext">Courses</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('admin/subjects/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.subjects.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.subjects.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-bookmark"></i>
                        </span>
                        <span class="pc-mtext">Subjects</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('admin/countries/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.countries.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.countries.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-world"></i>
                        </span>
                        <span class="pc-mtext">Countries</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('admin/boards/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.boards.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.boards.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-school"></i>
                        </span>
                        <span class="pc-mtext">Boards</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('admin/streams/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.streams.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.streams.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-flow"></i>
                        </span>
                        <span class="pc-mtext">Streams</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('admin/batches/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.batches.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.batches.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-calendar"></i>
                        </span>
                        <span class="pc-mtext">Batches</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('admin/teams/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.teams.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.teams.index')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-users"></i>
                        </span>
                        <span class="pc-mtext">Teams</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>
                
                
                <?php if(has_permission('admin/website/settings') || has_permission('profile/index')): ?>
                <li class="pc-item pc-caption">
                    <label>Settings</label>
                </li>
                <?php if(has_permission('admin/website/settings')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('admin.website.settings.*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.website.settings')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-settings"></i>
                        </span>
                        <span class="pc-mtext">Website Settings</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(has_permission('profile/index')): ?>
                <li class="pc-item <?php echo e(request()->routeIs('profile*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('profile')); ?>" class="pc-link">
                        <span class="pc-micon">
                            <i class="ti ti-user"></i>
                        </span>
                        <span class="pc-mtext">Profile</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<!-- [ Sidebar Menu ] end -->
<?php /**PATH D:\projects\crm-demo\resources\views/layouts/parts/sidebar.blade.php ENDPATH**/ ?>